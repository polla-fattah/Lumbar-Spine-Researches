# Revision Changelog — Committee-Readiness Update

**Date:** 2026-08-24

This pack was revised to address likely postgraduate research-committee objections.

## Master plan

- made ethics / de-identification explicit approval conditions;
- added 341 raw studies → 294 eligible cases → 299 reports reconciliation requirement;
- added data stewardship / authorship boundaries;
- removed publication guarantees;
- added project availability status.

## MSc 1

- removed "first in Iraq/Kurdistan" claim;
- removed population-prevalence framing;
- changed "age of onset" to age-at-imaging / age-specific frequency;
- added GEE / mixed-effects modelling for repeated lumbar levels;
- clarified degree fit and referral bias.

## MSc 2

- replaced test-time zeroing as the primary ablation with separately trained matched models;
- removed fixed ≥92% success criterion;
- removed "urgent surgical finding" terminology without surgical ground truth;
- required measured local sequence acquisition times;
- framed novelty as finding-specific local protocol validation, not invention of abbreviated MRI.

## MSc 3

- changed plural "hospitals" to singular hospital;
- made the contribution level-resolved relation extraction rather than generic LLM use;
- added locked test set, independent dual annotation / adjudication and inter-rater reliability;
- replaced personal "ownership" of the gold matrix with programme / institutional stewardship;
- made model family selection updateable at study start.

## MSc 4

- retained as unavailable until clinical data + ethics are confirmed;
- removed synthetic-outcome fallback;
- removed unsupported lateral-recess target;
- reduced AI dependence and added missingness / event-count safeguards.

## PhD / AMOG-Net

- revised novelty after Chai et al. 2026;
- no longer claims anatomy + multi-sequence + inter-level Transformer + ordinal grading as new;
- concentrates novelty on typed heterogeneous condition-level graph, disease-conditioned sequence routing, anatomical cross-sequence SSL and external zero-/few-shot transfer;
- removed NLP extraction as a mandatory PhD Phase 1 task;
- removed predetermined 95% recovery success threshold;
- strengthened closest-work baselines and ablation controls.

## Publication plan

- reduced salami-slicing risk;
- changed "floor" semantics to non-guaranteed fallback venue;
- made 3–4 submissions a working target rather than seven papers;
- made data descriptor explicitly conditional on separate public-release approval.

## New student-facing file

Added [`11_STUDENT_PROJECT_CATALOGUE.md`](11_STUDENT_PROJECT_CATALOGUE.md), which is the recommended document to publish to prospective students after institutional approval. The longer files remain the supervisor / committee pack.
